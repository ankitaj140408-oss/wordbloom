# WordBloom PWA

## What's included
- `index.html`: the vocabulary app
- `manifest.webmanifest`: app name, icon and install display settings
- `sw.js`: offline app-shell caching
- `icon-192.png` and `icon-512.png`: app icons

## Install on Android
A Progressive Web App must be served from HTTPS (or localhost) for installation and offline service-worker support. Opening `index.html` directly from Downloads is not enough.

1. Upload the contents of this folder to a static HTTPS host such as GitHub Pages or Netlify.
2. Open the published HTTPS address in Chrome on Android.
3. Open Chrome's menu and choose **Install app** or **Add to Home screen**.

Your vocabulary entries are stored in that browser's local storage. Use **Export backup** inside WordBloom before changing phones or clearing browser data.
